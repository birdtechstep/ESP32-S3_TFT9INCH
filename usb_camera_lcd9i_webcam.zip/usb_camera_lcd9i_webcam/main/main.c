// Copyright 2015-2020 Espressif Systems (Shanghai) PTE LTD
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at

//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include <stdio.h>
#include <string.h>
#include <assert.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/event_groups.h"

#include "esp_system.h"
#include "soc/efuse_reg.h"
#include "esp_heap_caps.h"
#include "esp_log.h"
#include "esp_spiffs.h"

#include "uvc_stream.h"
#include "jpegd2.h"

#include <nvs_flash.h>
#include <sys/param.h>
#include <stdlib.h>
#include "esp_lcd_panel_rgb.h"
#include "esp_lcd_panel_vendor.h"
#include "esp_lcd_panel_ops.h"
#include "driver/spi_master.h"
#include "driver/gpio.h"

esp_lcd_panel_handle_t panel_handle = NULL;

#define EXAMPLE_LCD_PIXEL_CLOCK_HZ     (12 * 1000 * 1000)
#define EXAMPLE_LCD_BK_LIGHT_ON_LEVEL  1
#define LCD_BK_LIGHT_ON_LEVEL  1
#define EXAMPLE_LCD_BK_LIGHT_OFF_LEVEL !EXAMPLE_LCD_BK_LIGHT_ON_LEVEL
#define EXAMPLE_PIN_NUM_BK_LIGHT       9

#define EXAMPLE_PIN_NUM_HSYNC          39
#define EXAMPLE_PIN_NUM_VSYNC          40
#define EXAMPLE_PIN_NUM_DE             41
#define EXAMPLE_PIN_NUM_PCLK           4
// RGB
//#define EXAMPLE_PIN_NUM_DATA0          5  // B0
//#define EXAMPLE_PIN_NUM_DATA1          6  // B1
//#define EXAMPLE_PIN_NUM_DATA2          7  // B2
//#define EXAMPLE_PIN_NUM_DATA3          15 // B3
//#define EXAMPLE_PIN_NUM_DATA4          16 // B4
// BGR
#define EXAMPLE_PIN_NUM_DATA0         21 // R0
#define EXAMPLE_PIN_NUM_DATA1         47 // R1
#define EXAMPLE_PIN_NUM_DATA2         48 // R2
#define EXAMPLE_PIN_NUM_DATA3         45 // R3
#define EXAMPLE_PIN_NUM_DATA4         38 // R4

#define EXAMPLE_PIN_NUM_DATA5          17 // G0
#define EXAMPLE_PIN_NUM_DATA6          18 // G1
#define EXAMPLE_PIN_NUM_DATA7          8  // G2
#define EXAMPLE_PIN_NUM_DATA8          3  // G3
#define EXAMPLE_PIN_NUM_DATA9          46 // G4
#define EXAMPLE_PIN_NUM_DATA10         14 // G5
// RGB
//#define EXAMPLE_PIN_NUM_DATA11         21 // R0
//#define EXAMPLE_PIN_NUM_DATA12         47 // R1
//#define EXAMPLE_PIN_NUM_DATA13         48 // R2
//#define EXAMPLE_PIN_NUM_DATA14         45 // R3
//#define EXAMPLE_PIN_NUM_DATA15         38 // R4
// BGR
#define EXAMPLE_PIN_NUM_DATA11          5  // B0
#define EXAMPLE_PIN_NUM_DATA12          6  // B1
#define EXAMPLE_PIN_NUM_DATA13          7  // B2
#define EXAMPLE_PIN_NUM_DATA14          15 // B3
#define EXAMPLE_PIN_NUM_DATA15          16 // B4

#define EXAMPLE_PIN_NUM_DISP_EN        -1

// The pixel number in horizontal and vertical
#define LCD_H_RES              800
#define LCD_V_RES              480

/* USB PIN fixed in esp32-s3, can not use io matrix */
#define BOARD_USB_DP_PIN 20
#define BOARD_USB_DN_PIN 19

/* USB Camera Descriptors Related MACROS,
the quick demo skip the standred get descriptors process,
users need to get params from camera descriptors from PC side,
eg. run `lsusb -v` in linux,
then hardcode the related MACROS below
*/
/*
 idVendor           0x046d Logitech, Inc.
 idProduct          0x082b Webcam C170
 bDescriptorSubtype                  6 (FORMAT_MJPEG)
 bFormatIndex                        2
 bInterfaceClass        14 Video
 bInterfaceSubClass      2 Video Streaming
 bEndpointAddress     0x82  EP 2 IN
 // ESP32S3 Support 1x 512 ALT 4
 bAlternateSetting       1
   wMaxPacketSize     0x1400  3x 1024 bytes
 bmAttributes            5
   wMaxPacketSize     0x0c00  2x 1024 bytes
 bAlternateSetting       3
   wMaxPacketSize     0x0400  1x 1024 bytes
 bAlternateSetting       4
   wMaxPacketSize     0x0200  1x 512 bytes
  */
#define DESCRIPTOR_CONFIGURATION_INDEX        1
#define DESCRIPTOR_FORMAT_UNCOMPRESSED_INDEX  1
#define DESCRIPTOR_FORMAT_MJPEG_INDEX         2

#define DESCRIPTOR_FORMAT_INDEX    DESCRIPTOR_FORMAT_MJPEG_INDEX

#define DESCRIPTOR_FRAME_640_480_INDEX  1
#define DESCRIPTOR_FRAME_352_288_INDEX  2
#define DESCRIPTOR_FRAME_320_240_INDEX  3
#define DESCRIPTOR_FRAME_176_144_INDEX  4
#define DESCRIPTOR_FRAME_160_120_INDEX  5
#define DESCRIPTOR_FRAME_544_288_INDEX  6
#define DESCRIPTOR_FRAME_432_240_INDEX  7
#define DESCRIPTOR_FRAME_320_176_INDEX  8
#define DESCRIPTOR_FRAME_640_360_INDEX  9

#define DESCRIPTOR_FRAME_5FPS_INTERVAL  2000000
#define DESCRIPTOR_FRAME_10FPS_INTERVAL 1000000
#define DESCRIPTOR_FRAME_15FPS_INTERVAL 666666
#define DESCRIPTOR_FRAME_30FPS_INTERVAL 333333

#ifdef CONFIG_SIZE_160_120
#define DEMO_FRAME_WIDTH      160
#define DEMO_FRAME_HEIGHT     120
#define DEMO_XFER_BUFFER_SIZE (20*1024) //(57600)
#define DEMO_FRAME_INDEX      DESCRIPTOR_FRAME_160_120_INDEX
#define DEMO_FRAME_INTERVAL   DESCRIPTOR_FRAME_30FPS_INTERVAL
#define PARALLEL_LINES        DEMO_FRAME_HEIGHT/2
#elif CONFIG_SIZE_176_144
#define DEMO_FRAME_WIDTH      176
#define DEMO_FRAME_HEIGHT     144
#define DEMO_XFER_BUFFER_SIZE (25*1024) //(76032)
#define DEMO_FRAME_INDEX      DESCRIPTOR_FRAME_176_144_INDEX
#define DEMO_FRAME_INTERVAL   DESCRIPTOR_FRAME_30FPS_INTERVAL
#define PARALLEL_LINES        DEMO_FRAME_HEIGHT/3
#elif CONFIG_SIZE_320_176
#define DEMO_FRAME_WIDTH      320
#define DEMO_FRAME_HEIGHT     176
#define DEMO_XFER_BUFFER_SIZE (30*1024) //(168960)
#define DEMO_FRAME_INDEX      DESCRIPTOR_FRAME_320_176_INDEX
#define DEMO_FRAME_INTERVAL   DESCRIPTOR_FRAME_30FPS_INTERVAL
#define PARALLEL_LINES        DEMO_FRAME_HEIGHT/4
#elif CONFIG_SIZE_320_240
#define DEMO_FRAME_WIDTH      320
#define DEMO_FRAME_HEIGHT     240
#define DEMO_XFER_BUFFER_SIZE (35*1024) //(230400)
#define DEMO_FRAME_INDEX      DESCRIPTOR_FRAME_320_240_INDEX
#define DEMO_FRAME_INTERVAL   DESCRIPTOR_FRAME_15FPS_INTERVAL
#define PARALLEL_LINES        DEMO_FRAME_HEIGHT/6
#elif CONFIG_SIZE_352_288
#define DEMO_FRAME_WIDTH      352
#define DEMO_FRAME_HEIGHT     288
#define DEMO_XFER_BUFFER_SIZE (40*1024) //(304128)
#define DEMO_FRAME_INDEX      DESCRIPTOR_FRAME_352_288_INDEX
#define DEMO_FRAME_INTERVAL   DESCRIPTOR_FRAME_15FPS_INTERVAL
#define PARALLEL_LINES        DEMO_FRAME_HEIGHT/8
#elif CONFIG_SIZE_432_240
#define DEMO_FRAME_WIDTH      432
#define DEMO_FRAME_HEIGHT     240
#define DEMO_XFER_BUFFER_SIZE (45*1024) //(311040)
#define DEMO_FRAME_INDEX      DESCRIPTOR_FRAME_432_240_INDEX
#define DEMO_FRAME_INTERVAL   DESCRIPTOR_FRAME_15FPS_INTERVAL
#define PARALLEL_LINES        DEMO_FRAME_HEIGHT/10
#elif CONFIG_SIZE_544_288
#define DEMO_FRAME_WIDTH      544
#define DEMO_FRAME_HEIGHT     288
#define DEMO_XFER_BUFFER_SIZE (50*1024) //(470016)
#define DEMO_FRAME_INDEX      DESCRIPTOR_FRAME_544_288_INDEX
#define DEMO_FRAME_INTERVAL   DESCRIPTOR_FRAME_10FPS_INTERVAL
#define PARALLEL_LINES        DEMO_FRAME_HEIGHT/8
#elif CONFIG_SIZE_640_360
#define DEMO_FRAME_WIDTH      640
#define DEMO_FRAME_HEIGHT     360
#define DEMO_XFER_BUFFER_SIZE (55*1024) //(691200)
#define DEMO_FRAME_INDEX      DESCRIPTOR_FRAME_640_360_INDEX
#define DEMO_FRAME_INTERVAL   DESCRIPTOR_FRAME_10FPS_INTERVAL
#define PARALLEL_LINES 10
#elif CONFIG_SIZE_640_480
#define DEMO_FRAME_WIDTH      640
#define DEMO_FRAME_HEIGHT     480
#define DEMO_XFER_BUFFER_SIZE (60*1024) //(921600)
#define DEMO_FRAME_INDEX      DESCRIPTOR_FRAME_640_480_INDEX
#define DEMO_FRAME_INTERVAL   DESCRIPTOR_FRAME_10FPS_INTERVAL
#define PARALLEL_LINES 10
#endif

#define DESCRIPTOR_STREAM_INTERFACE_INDEX       1
#define DESCRIPTOR_STREAM_INTERFACE_ALT_3X_1024 1
#define DESCRIPTOR_STREAM_INTERFACE_ALT_2X_1024 2
#define DESCRIPTOR_STREAM_INTERFACE_ALT_1X_1024 3
#define DESCRIPTOR_STREAM_INTERFACE_ALT_1X_512  4 //ESP32S3

// Video Streaming bEndpointAddress     0x82  EP 2 IN
#define DESCRIPTOR_STREAM_ISOC_ENDPOINT_ADDR 0x82
// max packet size 1*512, bigger is not supported*/
#define DEMO_ISOC_EP_MPS 512
#define DEMO_ISOC_INTERFACE_ALT DESCRIPTOR_STREAM_INTERFACE_ALT_1X_512

#ifdef CONFIG_BOOT_ANIMATION
#define BOOT_ANIMATION_MAX_SIZE (230400) //(45 * 1024)
#endif

#define DEMO_MAX_TRANFER_SIZE (DEMO_FRAME_WIDTH * DEMO_FRAME_HEIGHT * 2 + 100)

static const char *TAG = "uvc_demo";

static void *_malloc(size_t size)
{
    return heap_caps_malloc(size, MALLOC_CAP_SPIRAM);
}

static bool lcd_draw_image(uint16_t x, uint16_t y, uint16_t width, uint16_t height, uint8_t *img)
{
    uint8_t *fb = img;
	// Display center panel
    esp_lcd_panel_draw_bitmap(panel_handle,
                                    (LCD_H_RES/2) - (DEMO_FRAME_WIDTH/2),
                                y + (LCD_V_RES/2) - (DEMO_FRAME_HEIGHT/2),
                                    (LCD_H_RES/2) - (DEMO_FRAME_WIDTH/2)  + DEMO_FRAME_WIDTH,
                                y + (LCD_V_RES/2) - (DEMO_FRAME_HEIGHT/2) + DEMO_FRAME_HEIGHT,
                                fb);

    return true;
}

/* *******************************************************************************************
 * This callback function runs once per frame. Use it to perform any
 * quick processing you need, or have it put the frame into your application's
 * input queue. If this function takes too long, you'll start losing frames. */
static void frame_cb(uvc_frame_t *frame, void *ptr)
{
    assert(ptr);
    uint8_t *lcd_buffer = (uint8_t *)(ptr);
    ESP_LOGV(TAG, "callback! frame_format = %d, seq = %u, width = %d, height = %d, length = %u, ptr = %d",
             frame->frame_format, frame->sequence, frame->width, frame->height, frame->data_bytes, (int) ptr);

    switch (frame->frame_format) {
        case UVC_FRAME_FORMAT_MJPEG:
            mjpegdraw(frame->data, frame->data_bytes, lcd_buffer, DEMO_FRAME_WIDTH, DEMO_FRAME_HEIGHT, lcd_draw_image, LCD_H_RES, LCD_V_RES);
            vTaskDelay(10 / portTICK_PERIOD_MS); /* add delay to free cpu to other tasks */
            break;

        case UVC_FRAME_FORMAT_UNCOMPRESSED:
			// Not work
            vTaskDelay(10 / portTICK_PERIOD_MS); // add delay to free cpu to other tasks
            break;

        default:
            ESP_LOGW(TAG, "Format not supported");
            assert(0);
            break;
    }
}

void app_main(void)
{
    gpio_config_t bk_gpio_config = {
        .mode = GPIO_MODE_OUTPUT,
        .pin_bit_mask = 1ULL << EXAMPLE_PIN_NUM_BK_LIGHT
    };
    // Initialize the GPIO of backlight
    ESP_ERROR_CHECK(gpio_config(&bk_gpio_config));
	
    ESP_LOGI(TAG, "Install RGB panel driver");
    //esp_lcd_panel_handle_t panel_handle = NULL;
    esp_lcd_rgb_panel_config_t panel_config = {
        .data_width = 16, // RGB565 in parallel mode, thus 16bit in width
        //.psram_trans_align = 64,
        .clk_src = LCD_CLK_SRC_PLL160M, //LCD_CLK_SRC_DEFAULT,
        .disp_gpio_num = EXAMPLE_PIN_NUM_DISP_EN,
        .pclk_gpio_num = EXAMPLE_PIN_NUM_PCLK,
        .vsync_gpio_num = EXAMPLE_PIN_NUM_VSYNC,
        .hsync_gpio_num = EXAMPLE_PIN_NUM_HSYNC,
        .de_gpio_num = EXAMPLE_PIN_NUM_DE,
        .data_gpio_nums = {
            EXAMPLE_PIN_NUM_DATA0,
            EXAMPLE_PIN_NUM_DATA1,
            EXAMPLE_PIN_NUM_DATA2,
            EXAMPLE_PIN_NUM_DATA3,
            EXAMPLE_PIN_NUM_DATA4,
            EXAMPLE_PIN_NUM_DATA5,
            EXAMPLE_PIN_NUM_DATA6,
            EXAMPLE_PIN_NUM_DATA7,
            EXAMPLE_PIN_NUM_DATA8,
            EXAMPLE_PIN_NUM_DATA9,
            EXAMPLE_PIN_NUM_DATA10,
            EXAMPLE_PIN_NUM_DATA11,
            EXAMPLE_PIN_NUM_DATA12,
            EXAMPLE_PIN_NUM_DATA13,
            EXAMPLE_PIN_NUM_DATA14,
            EXAMPLE_PIN_NUM_DATA15,
        },
        .timings = {
            .pclk_hz = EXAMPLE_LCD_PIXEL_CLOCK_HZ,
            .h_res = LCD_H_RES,
            .v_res = LCD_V_RES,
            // The following parameters should refer to LCD spec
            .hsync_back_porch  = 26,
            .hsync_front_porch = 32,
            .hsync_pulse_width = 96,
            .vsync_back_porch  = 32,
            .vsync_front_porch = 23,
            .vsync_pulse_width = 2,
            .flags.pclk_active_neg = true,
        },
        .flags.fb_in_psram = 1, // allocate frame buffer in PSRAM
        .flags.relax_on_idle = 0,
    };
    ESP_ERROR_CHECK(esp_lcd_new_rgb_panel(&panel_config, &panel_handle));

    ESP_ERROR_CHECK(esp_lcd_panel_reset(panel_handle));
    ESP_ERROR_CHECK(esp_lcd_panel_init(panel_handle));

    // Turn on backlight (Different LCD screens may need different levels)
    ESP_ERROR_CHECK(gpio_set_level(EXAMPLE_PIN_NUM_BK_LIGHT, LCD_BK_LIGHT_ON_LEVEL));

    /* malloc a buffer for RGB565 data, as 320*240*2 = 153600B,
    here malloc a smaller buffer refresh lcd with steps */
    uint8_t *lcd_buffer = (uint8_t *)heap_caps_malloc(DEMO_MAX_TRANFER_SIZE,  MALLOC_CAP_SPIRAM);
    assert(lcd_buffer != NULL);

    /* Boot animation useful for LCD checking and camera power-on waiting, But consumes much flash */
#ifdef CONFIG_BOOT_ANIMATION
    esp_vfs_spiffs_conf_t spiffs_config = {
        .base_path              = "/spiffs",
        .partition_label        = NULL,
        .max_files              = 5,
        .format_if_mount_failed = false
    };

    ESP_ERROR_CHECK(esp_vfs_spiffs_register(&spiffs_config));

    uint8_t *jpeg_buf = malloc(BOOT_ANIMATION_MAX_SIZE);
    assert(jpeg_buf != NULL);

    for (size_t i = 10; i <= 90; i += 2) {
        char file_name[64] = {0};
        sprintf(file_name, "/spiffs/video/r%03d.jpg", i);
        FILE *fd = fopen(file_name, "r");
        int read_bytes = fread(jpeg_buf, 1, BOOT_ANIMATION_MAX_SIZE, fd);
        fclose(fd);
        mjpegdraw(jpeg_buf, read_bytes, lcd_buffer, DEMO_FRAME_WIDTH, DEMO_FRAME_HEIGHT, lcd_draw_image, LCD_H_RES, LCD_V_RES);
        ESP_LOGD(TAG, "file_name: %s, fd: %p, read_bytes: %d, free_heap: %d", file_name, fd, read_bytes, esp_get_free_heap_size());
    }

    free(jpeg_buf);
    ESP_LOGI(TAG, "Boot animation end.");
#endif

    /* malloc double buffer for usb payload, xfer_buffer_size >= frame_buffer_size*/
    uint8_t *xfer_buffer_a = (uint8_t *)_malloc(DEMO_XFER_BUFFER_SIZE);
    assert(xfer_buffer_a != NULL);
    uint8_t *xfer_buffer_b = (uint8_t *)_malloc(DEMO_XFER_BUFFER_SIZE);
    assert(xfer_buffer_b != NULL);

    /* malloc frame buffer for a jpeg frame*/
    uint8_t *frame_buffer = (uint8_t *)_malloc(DEMO_XFER_BUFFER_SIZE);
    assert(frame_buffer != NULL);

    /* the quick demo skip the standred get descriptors process,
    users need to get params from camera descriptors from PC side,
    eg. run `lsusb -v` in linux, then modify related MACROS */
    uvc_config_t uvc_config = {
        .dev_speed = USB_SPEED_FULL,
        .configuration = DESCRIPTOR_CONFIGURATION_INDEX,
        .format_index = DESCRIPTOR_FORMAT_INDEX,
        .frame_width = DEMO_FRAME_WIDTH,
        .frame_height = DEMO_FRAME_HEIGHT,
        .frame_index = DEMO_FRAME_INDEX,
        .frame_interval = DEMO_FRAME_INTERVAL,
        .interface = DESCRIPTOR_STREAM_INTERFACE_INDEX,
        .interface_alt = DEMO_ISOC_INTERFACE_ALT,
        .isoc_ep_addr = DESCRIPTOR_STREAM_ISOC_ENDPOINT_ADDR,
        .isoc_ep_mps = DEMO_ISOC_EP_MPS,
        .xfer_buffer_size = DEMO_XFER_BUFFER_SIZE,
        .xfer_buffer_a = xfer_buffer_a,
        .xfer_buffer_b = xfer_buffer_b,
        .frame_buffer_size = DEMO_XFER_BUFFER_SIZE,
        .frame_buffer = frame_buffer,
    };

    /* pre-config UVC driver with params from known USB Camera Descriptors*/
    esp_err_t ret = uvc_streaming_config(&uvc_config);

    /* Start camera IN stream with pre-configs, uvc driver will create multi-tasks internal
    to handle usb data from different pipes, and user's callback will be called after new frame ready. */
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "uvc streaming config failed");
    } else {
#ifdef CONFIG_SOURCE_SIMULATE
        uvc_streaming_simulate_start(frame_cb, (void *)(lcd_buffer));
#else
        uvc_streaming_start(frame_cb, (void *)(lcd_buffer));
#endif
    }

    while (1) {
        /* task monitor code if necessary */
        vTaskDelay(1000 / portTICK_PERIOD_MS);
    }

}
